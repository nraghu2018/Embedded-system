/* ========================================
 *
 * Copyright 2018 Michael McCormack
 * All Rights Reserved
 *
 * Permission is hereby granted, free of charge, to any person obtaining 
 * a copy of this software and associated documentation files (the "Software"), 
 * to deal in the Software without restriction, including without limitation 
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, 
 * and/or sell copies of the Software, and to permit persons to whom the 
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included 
 * in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * ========================================
*/
#include "project.h"
#include "FreeRTOS.h"
#include "timers.h"
#include "task.h"



extern void RTOS_Start(void);

/*  */ 


#define STR_LEN 32
#define RX_BUF_LEN 128

#define SPACE ' '
#define TAB '\t'
#define CR  '\r'
#define LF  '\n'

inline int is_delimiter(uint8_t c)
{
    int result = 0 ;
    switch(c) {
    case CR:
    case LF:
    case TAB:
    case SPACE:
        result = c ;
        break ;
    }
    return( result ) ;
}

volatile char          rx_buf[RX_BUF_LEN] ;
volatile int           rx_write_index = 0 ;
int           rx_read_index = 0 ;
char          str[STR_LEN+1] ; /* print buffer */
int           str_index = 0 ;
int           str_ready = 0 ;

CY_ISR(rx_isr)
{    
    int_rx_ClearPending() ;
    while(UART_GetRxBufferSize()) {
        rx_buf[rx_write_index] = UART_GetByte() ;
        rx_write_index = (rx_write_index + 1) % RX_BUF_LEN ;
    }
}

void print(char *str)
{
    UART_PutString(str) ;
}

void help(void)
{
    print("============== usage ===============\n") ;
    print("led {on | off}  : turn LED on or off\n") ;
    print("help            : print this\n") ;
    print("=====================================\n") ;
}

void init_hardware(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    LED_Write(0) ;
        
    int_rx_ClearPending() ;
    int_rx_StartEx(rx_isr) ;
    UART_Start() ;
}

void splash(void)
{
    char str[64] ;
    sprintf(str, "PSoC 5LP UART Command Test (%s %s)\n", __DATE__, __TIME__) ;
    print(str) ;
}

void prompt(void)
{
    print("> ") ;
}

int check_str(void)
{
    int result = 0 ;
    uint8_t c ;
    while((result == 0) && (rx_read_index != rx_write_index)) {
        c = rx_buf[rx_read_index] ;
        rx_read_index = (rx_read_index + 1) % RX_BUF_LEN ;
        result = is_delimiter(c) ;
        if (result) { /* a string delimter was detected */
            str[str_index] = '\0' ;
            str_index = 0 ;
            str_index = 1 ;
        } else { /* still in the middle of a string */
            if (str_index < STR_LEN) { /* string is too long */
                str[str_index++]=c ;
            }
            else {
                str[STR_LEN]='\0';
                str_index = 0 ;
                result = -1 ;
            }
        }      
    }
    return( result ) ;
}

int get_str(void)
{
    int result = 0 ;
    while(result == 0) {
        result = check_str() ;
    }
    return( result ) ;
}

void str2upper(char *str)
{
    while(str && *str) {
        if (('a' <= *str) && (*str <= 'z')) {
            *str -= ('a' - 'A') ;
        }
        str++ ;
    }
}

void do_led(void)
{
    while(get_str() == 0) ;
    str2upper(str) ;
    if (strcmp(str, "ON") == 0) {
        LED_Write(1) ;
        print("LED is ON\n") ;
    } else {
        LED_Write(0) ;
        print("LED is OFF\n") ;
    }
}



void do_command(char *str)
{
    str2upper(str) ;
    if (strcmp(str, "LED") == 0) {
        do_led() ;
    } else {
        help() ;
    }
}


void uartTask(void *arg)
{
   (void)arg;
   init_hardware() ;
    
    splash() ;

    prompt() ;
    for(;;)
    {
        if (check_str()) { /* a string was recived in str[] */
            do_command(str) ;
            prompt() ;
        }
    }
}


int main(void)
{
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    RTOS_Start();
    
    xTaskCreate(uartTask,"UART Task",configMINIMAL_STACK_SIZE,0,1,0);
    vTaskStartScheduler();  // TODO Should never return, add reset after
  
    for(;;)
    {
    
    }
}

/* [] END OF FILE */
