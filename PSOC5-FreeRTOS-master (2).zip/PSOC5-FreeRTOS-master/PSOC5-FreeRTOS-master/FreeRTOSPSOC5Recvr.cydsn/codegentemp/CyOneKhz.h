/*******************************************************************************
* File Name: CyOneKhz.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_CyOneKhz_H)
#define CY_CLOCK_CyOneKhz_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void CyOneKhz_Start(void) ;
void CyOneKhz_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void CyOneKhz_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void CyOneKhz_StandbyPower(uint8 state) ;
void CyOneKhz_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 CyOneKhz_GetDividerRegister(void) ;
void CyOneKhz_SetModeRegister(uint8 modeBitMask) ;
void CyOneKhz_ClearModeRegister(uint8 modeBitMask) ;
uint8 CyOneKhz_GetModeRegister(void) ;
void CyOneKhz_SetSourceRegister(uint8 clkSource) ;
uint8 CyOneKhz_GetSourceRegister(void) ;
#if defined(CyOneKhz__CFG3)
void CyOneKhz_SetPhaseRegister(uint8 clkPhase) ;
uint8 CyOneKhz_GetPhaseRegister(void) ;
#endif /* defined(CyOneKhz__CFG3) */

#define CyOneKhz_Enable()                       CyOneKhz_Start()
#define CyOneKhz_Disable()                      CyOneKhz_Stop()
#define CyOneKhz_SetDivider(clkDivider)         CyOneKhz_SetDividerRegister(clkDivider, 1u)
#define CyOneKhz_SetDividerValue(clkDivider)    CyOneKhz_SetDividerRegister((clkDivider) - 1u, 1u)
#define CyOneKhz_SetMode(clkMode)               CyOneKhz_SetModeRegister(clkMode)
#define CyOneKhz_SetSource(clkSource)           CyOneKhz_SetSourceRegister(clkSource)
#if defined(CyOneKhz__CFG3)
#define CyOneKhz_SetPhase(clkPhase)             CyOneKhz_SetPhaseRegister(clkPhase)
#define CyOneKhz_SetPhaseValue(clkPhase)        CyOneKhz_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(CyOneKhz__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define CyOneKhz_CLKEN              (* (reg8 *) CyOneKhz__PM_ACT_CFG)
#define CyOneKhz_CLKEN_PTR          ((reg8 *) CyOneKhz__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define CyOneKhz_CLKSTBY            (* (reg8 *) CyOneKhz__PM_STBY_CFG)
#define CyOneKhz_CLKSTBY_PTR        ((reg8 *) CyOneKhz__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define CyOneKhz_DIV_LSB            (* (reg8 *) CyOneKhz__CFG0)
#define CyOneKhz_DIV_LSB_PTR        ((reg8 *) CyOneKhz__CFG0)
#define CyOneKhz_DIV_PTR            ((reg16 *) CyOneKhz__CFG0)

/* Clock MSB divider configuration register. */
#define CyOneKhz_DIV_MSB            (* (reg8 *) CyOneKhz__CFG1)
#define CyOneKhz_DIV_MSB_PTR        ((reg8 *) CyOneKhz__CFG1)

/* Mode and source configuration register */
#define CyOneKhz_MOD_SRC            (* (reg8 *) CyOneKhz__CFG2)
#define CyOneKhz_MOD_SRC_PTR        ((reg8 *) CyOneKhz__CFG2)

#if defined(CyOneKhz__CFG3)
/* Analog clock phase configuration register */
#define CyOneKhz_PHASE              (* (reg8 *) CyOneKhz__CFG3)
#define CyOneKhz_PHASE_PTR          ((reg8 *) CyOneKhz__CFG3)
#endif /* defined(CyOneKhz__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define CyOneKhz_CLKEN_MASK         CyOneKhz__PM_ACT_MSK
#define CyOneKhz_CLKSTBY_MASK       CyOneKhz__PM_STBY_MSK

/* CFG2 field masks */
#define CyOneKhz_SRC_SEL_MSK        CyOneKhz__CFG2_SRC_SEL_MASK
#define CyOneKhz_MODE_MASK          (~(CyOneKhz_SRC_SEL_MSK))

#if defined(CyOneKhz__CFG3)
/* CFG3 phase mask */
#define CyOneKhz_PHASE_MASK         CyOneKhz__CFG3_PHASE_DLY_MASK
#endif /* defined(CyOneKhz__CFG3) */

#endif /* CY_CLOCK_CyOneKhz_H */


/* [] END OF FILE */
