/*******************************************************************************
* File Name: Onboard_LED.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Onboard_LED_H) /* Pins Onboard_LED_H */
#define CY_PINS_Onboard_LED_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Onboard_LED_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Onboard_LED__PORT == 15 && ((Onboard_LED__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Onboard_LED_Write(uint8 value);
void    Onboard_LED_SetDriveMode(uint8 mode);
uint8   Onboard_LED_ReadDataReg(void);
uint8   Onboard_LED_Read(void);
void    Onboard_LED_SetInterruptMode(uint16 position, uint16 mode);
uint8   Onboard_LED_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Onboard_LED_SetDriveMode() function.
     *  @{
     */
        #define Onboard_LED_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Onboard_LED_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Onboard_LED_DM_RES_UP          PIN_DM_RES_UP
        #define Onboard_LED_DM_RES_DWN         PIN_DM_RES_DWN
        #define Onboard_LED_DM_OD_LO           PIN_DM_OD_LO
        #define Onboard_LED_DM_OD_HI           PIN_DM_OD_HI
        #define Onboard_LED_DM_STRONG          PIN_DM_STRONG
        #define Onboard_LED_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Onboard_LED_MASK               Onboard_LED__MASK
#define Onboard_LED_SHIFT              Onboard_LED__SHIFT
#define Onboard_LED_WIDTH              1u

/* Interrupt constants */
#if defined(Onboard_LED__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Onboard_LED_SetInterruptMode() function.
     *  @{
     */
        #define Onboard_LED_INTR_NONE      (uint16)(0x0000u)
        #define Onboard_LED_INTR_RISING    (uint16)(0x0001u)
        #define Onboard_LED_INTR_FALLING   (uint16)(0x0002u)
        #define Onboard_LED_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Onboard_LED_INTR_MASK      (0x01u) 
#endif /* (Onboard_LED__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Onboard_LED_PS                     (* (reg8 *) Onboard_LED__PS)
/* Data Register */
#define Onboard_LED_DR                     (* (reg8 *) Onboard_LED__DR)
/* Port Number */
#define Onboard_LED_PRT_NUM                (* (reg8 *) Onboard_LED__PRT) 
/* Connect to Analog Globals */                                                  
#define Onboard_LED_AG                     (* (reg8 *) Onboard_LED__AG)                       
/* Analog MUX bux enable */
#define Onboard_LED_AMUX                   (* (reg8 *) Onboard_LED__AMUX) 
/* Bidirectional Enable */                                                        
#define Onboard_LED_BIE                    (* (reg8 *) Onboard_LED__BIE)
/* Bit-mask for Aliased Register Access */
#define Onboard_LED_BIT_MASK               (* (reg8 *) Onboard_LED__BIT_MASK)
/* Bypass Enable */
#define Onboard_LED_BYP                    (* (reg8 *) Onboard_LED__BYP)
/* Port wide control signals */                                                   
#define Onboard_LED_CTL                    (* (reg8 *) Onboard_LED__CTL)
/* Drive Modes */
#define Onboard_LED_DM0                    (* (reg8 *) Onboard_LED__DM0) 
#define Onboard_LED_DM1                    (* (reg8 *) Onboard_LED__DM1)
#define Onboard_LED_DM2                    (* (reg8 *) Onboard_LED__DM2) 
/* Input Buffer Disable Override */
#define Onboard_LED_INP_DIS                (* (reg8 *) Onboard_LED__INP_DIS)
/* LCD Common or Segment Drive */
#define Onboard_LED_LCD_COM_SEG            (* (reg8 *) Onboard_LED__LCD_COM_SEG)
/* Enable Segment LCD */
#define Onboard_LED_LCD_EN                 (* (reg8 *) Onboard_LED__LCD_EN)
/* Slew Rate Control */
#define Onboard_LED_SLW                    (* (reg8 *) Onboard_LED__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Onboard_LED_PRTDSI__CAPS_SEL       (* (reg8 *) Onboard_LED__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Onboard_LED_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Onboard_LED__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Onboard_LED_PRTDSI__OE_SEL0        (* (reg8 *) Onboard_LED__PRTDSI__OE_SEL0) 
#define Onboard_LED_PRTDSI__OE_SEL1        (* (reg8 *) Onboard_LED__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Onboard_LED_PRTDSI__OUT_SEL0       (* (reg8 *) Onboard_LED__PRTDSI__OUT_SEL0) 
#define Onboard_LED_PRTDSI__OUT_SEL1       (* (reg8 *) Onboard_LED__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Onboard_LED_PRTDSI__SYNC_OUT       (* (reg8 *) Onboard_LED__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Onboard_LED__SIO_CFG)
    #define Onboard_LED_SIO_HYST_EN        (* (reg8 *) Onboard_LED__SIO_HYST_EN)
    #define Onboard_LED_SIO_REG_HIFREQ     (* (reg8 *) Onboard_LED__SIO_REG_HIFREQ)
    #define Onboard_LED_SIO_CFG            (* (reg8 *) Onboard_LED__SIO_CFG)
    #define Onboard_LED_SIO_DIFF           (* (reg8 *) Onboard_LED__SIO_DIFF)
#endif /* (Onboard_LED__SIO_CFG) */

/* Interrupt Registers */
#if defined(Onboard_LED__INTSTAT)
    #define Onboard_LED_INTSTAT            (* (reg8 *) Onboard_LED__INTSTAT)
    #define Onboard_LED_SNAP               (* (reg8 *) Onboard_LED__SNAP)
    
	#define Onboard_LED_0_INTTYPE_REG 		(* (reg8 *) Onboard_LED__0__INTTYPE)
#endif /* (Onboard_LED__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Onboard_LED_H */


/* [] END OF FILE */
